<?php
include('server/database/mysql.php');

session_start();

if(isset($_SESSION['user_id'])){
  
} else {
    header('Location: login.html');
}

// Cancela o agendamento com o ID fornecido
if(isset($_GET['id'])){
    $stmt = $pdo->prepare('UPDATE agendamentos SET status = "confirmado" WHERE id = :id');
    $stmt->bindParam(':id', $_GET['id']);
    $stmt->execute();
}

// Redireciona de volta para a página principal de agendamento
header('Location: agendamentos.php');
?>