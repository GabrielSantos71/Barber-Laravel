<?php
include('server/database/mysql.php');

session_start();

if(isset($_SESSION['user_id'])){
    $user_id = $_SESSION['user_id'];
} else {
    header('Location: login.html');
    exit();
}

$site_id = $_GET['id'] ?? ''; // Obtém o ID do site enviado por GET

$stmt = $pdo->prepare('SELECT * FROM agendamentos WHERE site_id = :site_id');
$stmt->bindParam(':site_id', $site_id);
$stmt->execute();
$agendamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);


// Verifica se foi enviado um filtro por status
$statusFilter = isset($_GET['status']) ? $_GET['status'] : '';

// Consulta no banco de dados com filtro por status
if (!empty($statusFilter)) {
    $stmt = $pdo->prepare('SELECT * FROM agendamentos WHERE status = :status');
    $stmt->bindParam(':status', $statusFilter);
    $stmt->execute();
    $agendamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

?>

<!DOCTYPE html>
<html>

<head>
    <title>Agendamentos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
</head>

<body>
    <div class="sidebar">
        <h1 class="text-center my-3 text-danger">Barber</h1>
        <ul class="mx-2">
            <a href="dashboard.php">
                <li>Sua Barbearia</li>
            </a>
        </ul>
        <ul class="mx-2">
            <a href="logout.php">
                <li>Logout</li>
            </a>
        </ul>
    </div>

    <div class="content">
        <div class="container mt-4">
            <h1 class="text-center mb-6">Agendamentos</h1>

            <form method="get" action="" class="mb-3">
                <div class="form-row align-items-center">
                    <div class="col-auto">
                        <label class="sr-only" for="status">Filtrar por status:</label>
                        <select name="status" id="status" class="form-control">
                            <option value="Pendente" <?php if($statusFilter == 'Pendente') echo 'selected'; ?>> Pendentes </option>
                            <option value="Confirmado" <?php if($statusFilter == 'Confirmado') echo 'selected'; ?>>
                                Aceito</option>
                            <option value="Cancelado" <?php if($statusFilter == 'Cancelado') echo 'selected'; ?>>
                                Cancelado</option>
                        </select>
                    </div>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-danger">Filtrar</button>
                    </div>
                </div>
            </form>

            <table class="table">
                <!-- Cabeçalho da tabela -->
                <thead class="text-white">
                    <tr>
                        <th>ID</th>
                        <th>Site</th>
                        <th>Unidade</th>
                        <th>Serviço</th>
                        <th>Data</th>
                        <th>Hora</th>
                        <th>Funcionário</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody class="text-white">
                    <?php foreach ($agendamentos as $agendamento) { ?>
                    <!-- Linhas da tabela -->
                    <tr>
                        <td><?php echo $agendamento['id']; ?></td>
                        <td><?php echo $agendamento['site_id']; ?></td>
                        <td><?php echo $agendamento['unidade']; ?></td>
                        <td><?php echo $agendamento['servico']; ?></td>
                        <td><?php echo $agendamento['data']; ?></td>
                        <td><?php echo $agendamento['hora']; ?></td>
                        <td><?php echo $agendamento['funcionario']; ?></td>
                        <td class="text-uppercase"><?php echo $agendamento['status']; ?></td>
                        <td>
                            <a href="acceptStatus.php?id=<?php echo $agendamento['id']; ?>"
                                onclick="return confirm('Tem certeza que deseja aceitar este agendamento?')"
                                class="btn btn-success">Aceitar</a>
                            <a href="cancelAgenda.php?id=<?php echo $agendamento['id']; ?>"
                                onclick="return confirm('Tem certeza que deseja cancelar este agendamento?')"
                                class="btn btn-danger">Cancelar</a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>