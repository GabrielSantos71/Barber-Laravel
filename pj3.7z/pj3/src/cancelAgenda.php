<?php
include('server/database/mysql.php');

session_start();

if(isset($_SESSION['user_id'])){
  
} else {
    header('Location: oauth/login.php');
}

// Cancela o agendamento com o ID fornecido
if(isset($_GET['id'])){
    $stmt = $pdo->prepare('UPDATE agendamentos SET status = "cancelado" WHERE id = :id');
    $stmt->bindParam(':id', $_GET['id']);
    $stmt->execute();
}

// Redireciona de volta para a página principal de agendamento
header('Location: agendamentos.php');
?>