<?php

include('server/database/mysql.php');

session_start();

if(isset($_SESSION['user_id'])){
  
} else {
    header('Location: login.html');
}

?>


<!DOCTYPE html>
<html>
<head>
    <title>Agendamento</title>
    <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
</head>
<body>
    <form method="POST" action="processAgenda.php">
        <h1>Agendamento</h1>
        <?php

                echo '<select name="unidades">';
                $sql = "SELECT * FROM unidades";
                $stmt = $pdo->query($sql);
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo '<option value="' . $row["id"] . '">' . $row["nome"] . '</option>';
                }
                echo '</select>';

                echo '<select name="servicos">';
                $stmt = $pdo->query('SELECT id, nome FROM servicos');
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo '<option value="' . $row["id"] . '">' . $row["nome"] . '</option>';
                }
                echo '</select>';


                echo '<select name="data">';
                $stmt = $pdo->query('SELECT id, data, hora FROM disponiveis');
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo '<option value="' . $row["id"] . '">' . $row["data"] . ' ' . $row["hora"] . '</option>';
                }
                echo '</select>';


                echo '<select name="funcionarios">';
                $stmt = $pdo->query('SELECT id, nome FROM funcionarios');
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo '<option value="' . $row["id"] . '">' . $row["nome"] . '</option>';
                }
                echo '</select>';

        ?>

        <input type="submit" value="Enviar">
    </form>
</body>
</html>
