<?php
session_start();
include('server/database/mysql.php');
if(isset($_SESSION['user_id'])){
    $user_id = $_SESSION['user_id'];
} else {
    header('Location: login.html');
}
echo ' Seu ID:' . $user_id = $_SESSION['user_id'] .  '';
?>

<!DOCTYPE html>
<html>

<head>
    <title>Agendamentos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
    <div class="sidebar">
        <h1 class="text-center my-3 text-danger">Barber</h1>
        <ul class="mx-2">
            <a href="">
                <li>Sua Barbearia</li>
            </a>
        </ul>
        <ul class="mx-2">
            <a href="logout.php">
                <li>Logout</li>
            </a>
        </ul>
    </div>

    <div class="content">
        <div class="container mt-4">
            <h1 class="text-left mb-6">Dashboard</h1>

            <?php

if (isset($_SESSION['user_id'])) {
    $id = $_SESSION['user_id'];
    $stmt = $pdo->prepare("SELECT * FROM sites WHERE user_id = :id");
    $stmt->execute([
        'id' => $id
    ]);
    if ($stmt->rowCount() > 0) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        echo '<div class="card mt-6">';
        echo '<img src="' . $row['logo'] . '" class="" alt="Logo">';
        echo '<div class="card-body">';
        echo '<h3 class="card-title">' . $row['title'] . '</h3>';
        echo '<a href="agendamentos.php?id='. $row['id'] . '" class="btn btn-danger">Agendamentos</a>';
        echo '<a href="server/edit/editSite.php?id='. $row['id'] . '" class="btn btn-danger">Gerenciar Site</a>';
        echo '<a href="server/create/createUnidades.php?id='. $row['id'] . '" class="btn btn-danger">Criar Unidades</a>';
        echo '<a href="server/create/createServicos.php?id='. $row['id'] . '" class="btn btn-danger">Criar Serviços</a>';
        echo '<a href="server/create/createFuncionarios.php?id='. $row['id'] . '" class="btn btn-danger">Criar Funcionários</a>';
        echo '<a href="server/create/createDisponiveis.php?id='. $row['id'] . '" class="btn btn-danger">Criar Horários</a>';
        echo '<a href="server/view/site.php?id='. $row['id'] . '" class="btn btn-success">Ver o Site</a>';
        echo '<p>' . 'http://localhost/pj3/src/server/view/site.php?id='. $row['id'] .'' . '</p>';
        echo '</div>';
        echo '</div>';
    } else {

        echo '
        <form action="server/oauth/processSite.php" method="POST" enctype="multipart/form-data">
        <input style="display: none" value="' . $id . '" type="text" id="user_id" name="user_id" required>
            <div class="form-group">
                <label for="title">Título:</label>
                <input type="text" id="title" name="title" required class="form-control">
            </div>
            <div class="form-group">
                <label for="text_sobre">Texto Sobre:</label>
                <textarea id="text_sobre" name="text_sobre" required class="form-control"></textarea>
            </div>
            <div class="form-group">
                <label for="logo">Logo:</label>
                <input type="text" id="logo" name="logo" required class="form-control">
            </div>
            <div class="form-group">
                <label for="imagen">Imagem:</label>
                <input type="text" id="imagen" name="imagen" required class="form-control">
            </div>
            <div class="form-group">
                <label for="primary_color">Cor Primária:</label>
                <input type="color" id="primary_color" name="primary_color" required class="form-control">
            </div>
            <div class="form-group">
                <label for="secondary_color">Cor Secundária:</label>
                <input type="color" id="secondary_color" name="secondary_color" required class="form-control">
            </div>
            <div class="form-group">
                <label for="text_color">Cor do Texto:</label>
                <input type="color" id="text_color" name="text_color" required class="form-control">
            </div>
            <input type="submit" value="Enviar" class="btn btn-danger">
            </form>';
            }
            }
            ?>


        </div>
    </div>

    </div>

</body>

</html>