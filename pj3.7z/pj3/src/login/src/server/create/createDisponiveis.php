<?php

include('../database/mysql.php');

if (!isset($_GET['id'])) {
    echo 'ID do site não especificado.';
    exit();
}

$id = $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM sites WHERE id = :id");
$stmt->execute([
    'id' => $id
]);


if ($stmt->rowCount() === 0) {
    echo 'Site não encontrado.';
    exit();
}

$site = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $data = $_POST['data'];
    $hora = $_POST['hora'];
    $idu = $_POST['unidade'];


    $stmt = $pdo->prepare("INSERT INTO disponiveis (data, hora, site_id, unidade_id) VALUES (:data, :hora, :site_id, :unidade_id)");

    try {
        $stmt->execute([
            'data' => $data,
            'hora' => $hora,
            'site_id' => $id,
            'unidade_id' => $idu
        ]);
        header('Location: ../../dashboard.php');
        exit();
    } catch (PDOException $e) {
        echo 'Erro ao criar o funcionário: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../../assets/css/form.css">
    <title>Criar Horários</title>
</head>
<body>
    <form action="" method="POST">
        <label for="data">Data:</label>
        <input type="date" id="data" name="data" required>

        <label for="hora">Hora:</label>
        <input type="time" id="hora" name="hora" required>


        <label for="unidade">Unidade:</label>
        <select name="unidade">
    <?php

    $stmt = $pdo->prepare("SELECT id, nome FROM unidades WHERE site_id = :id");
    $stmt->bindParam(':id', $id);
    $stmt->execute();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $unidadeId = $row['id'];
            $unidadeName = $row['nome'];
            echo '<option value="' . $unidadeId . '">' . $unidadeName . '</option>';
        }
    ?>
</select>

        <input type="submit" value="Criar Horários">
        <a href="../../dashboard.php">Voltar</a>
    </form>
</body>
</html>