<?php

include('../database/mysql.php');

if (!isset($_GET['id'])) {
    echo 'ID do site não especificado.';
    exit();
}

$id = $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM sites WHERE id = :id");
$stmt->execute([
    'id' => $id
]);

if ($stmt->rowCount() === 0) {
    echo 'Site não encontrado.';
    exit();
}

$site = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nome = $_POST['nome'];
    $endereco = $_POST['endereco'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
    $telefone = $_POST['telefone'];

    $stmt = $pdo->prepare("INSERT INTO unidades (nome, endereco, cidade, estado, telefone, site_id) VALUES (:nome, :endereco, :cidade, :estado, :telefone, :site_id)");

    try {
        $stmt->execute([
            'nome' => $nome,
            'endereco' => $endereco,
            'cidade' => $cidade,
            'estado' => $estado,
            'telefone' => $telefone,
            'site_id' => $id
        ]);
        header('../../dashboard.php');
    } catch (PDOException $e) {
        echo 'Erro ao criar a unidade: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../../assets/css/form.css">
    <title>Criar Unidade</title>
</head>
<body>
    <form action="" method="POST">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" required>

        <label for="endereco">Endereço:</label>
        <input type="text" id="endereco" name="endereco" required>

        <label for="cidade">Cidade:</label>
        <input type="text" id="cidade" name="cidade" required>

        <label for="estado">Estado:</label>
        <input type="text" id="estado" name="estado" required>

        <label for="telefone">Telefone:</label>
        <input type="text" id="telefone" name="telefone" required>

        <input type="submit" value="Criar Unidade">
        <a href="../../dashboard.php">Voltar</a>
    </form>
</body>
</html>