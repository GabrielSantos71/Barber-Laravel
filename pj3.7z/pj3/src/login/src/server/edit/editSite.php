<?php

include('../database/mysql.php');

// Verifica se o parâmetro 'id' foi passado via GET
if (!isset($_GET['id'])) {
    echo 'ID do site não especificado.';
    exit();
}

$id = $_GET['id'];

// Consulta os dados do site pelo ID
$query = "SELECT * FROM sites WHERE id = :id";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->execute();

// Verifica se o site foi encontrado
if ($stmt->rowCount() === 0) {
    echo 'Site não encontrado.';
    exit();
}

// Recupera os dados do site
$site = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Editar Site</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../../assets/css/edit.css">
</head>

<body>
    <form method="POST" action="updateSite.php">
        <input type="hidden" name="id" value="<?php echo $site['id']; ?>">
        <label for="title">Título:</label>
        <input type="text" name="title" id="title" value="<?php echo $site['title']; ?>"><br>
        <label for="text_sobre">Texto Sobre:</label><br>
        <textarea name="text_sobre" id="text_sobre"><?php echo $site['text_sobre']; ?></textarea><br>
        <label for="logo">Logo:</label>
        <img width="100px" src="<?php echo $site['logo']; ?>"/>
        <input type="text" name="logo" id="logo" value="<?php echo $site['logo']; ?>"><br>
        <label for="imagen">Imagem:</label>
        <img width="100px" src="<?php echo $site['imagen']; ?>"/>
        <input type="text" name="imagen" id="imagen" value="<?php echo $site['imagen']; ?>"><br>
        <label for="primary_color">Cor Primária:</label>
        <input type="color" name="primary_color" id="primary_color" value="<?php echo $site['primary_color']; ?>"><br>
        <label for="secondary_color">Cor Secundária:</label>
        <input type="color" name="secondary_color" id="secondary_color" value="<?php echo $site['secondary_color']; ?>"><br>
        <label for="text_color">Cor do Texto:</label>
        <input type="color" name="text_color" id="text_color" value="<?php echo $site['text_color']; ?>"><br>
        
        <input type="submit" value="Atualizar">
    </form>
</body>

</html>