<?php

include('../database/mysql.php');

if (!isset($_POST['id'])) {
    echo 'ID do site não especificado.';
    exit();
}

$id = $_POST['id'];
$title = $_POST['title'];
$text_sobre = $_POST['text_sobre'];
$logo = $_POST['logo'];
$imagen = $_POST['imagen'];
$primary_color = $_POST['primary_color'];
$secondary_color = $_POST['secondary_color'];
$text_color = $_POST['text_color'];

// Atualiza os dados do site
$query = "UPDATE sites SET title = :title, text_sobre = :text_sobre, logo = :logo, imagen = :imagen, primary_color = :primary_color, secondary_color = :secondary_color, text_color = :text_color WHERE id = :id";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->bindParam(':title', $title, PDO::PARAM_STR);
$stmt->bindParam(':text_sobre', $text_sobre, PDO::PARAM_STR);
$stmt->bindParam(':logo', $logo, PDO::PARAM_STR);
$stmt->bindParam(':imagen', $imagen, PDO::PARAM_STR);
$stmt->bindParam(':primary_color', $primary_color, PDO::PARAM_STR);
$stmt->bindParam(':secondary_color', $secondary_color, PDO::PARAM_STR);
$stmt->bindParam(':text_color', $text_color, PDO::PARAM_STR);
$stmt->execute();

echo 'Site atualizado com sucesso!';
echo '<a href="../../dashboard.php">Voltar</a>';

?>