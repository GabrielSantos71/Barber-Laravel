<?php

include("../database/mysql.php");

try {
    
    // Prepara a instrução SQL para inserção dos dados
    $stmt = $pdo->prepare("INSERT INTO barbeiros (nome, cpf_cnpj, email, endereco, bairro, cidade, estado, cep, senha) VALUES (:nome, :cpf_cnpj, :email, :endereco, :bairro, :cidade, :estado, :cep, :senha)");
    
    // Parâmetros do formulário
    $nome      = $_POST['Name'];
    $cpf_cnpj  = $_POST['cpf'];
    $email     = $_POST['email'];
    $endereco  = $_POST['address1'];
    $bairro    = $_POST['bairro'];
    $cidade    = $_POST['city'];
    $estado    = $_POST['state'];
    $cep       = $_POST['cep'];
    $senha     = $_POST['senha'];
    
    // Executa a instrução SQL com os parâmetros do formulário
    $stmt->execute(array(
        'nome'      => $nome,
        'cpf_cnpj'  => $cpf_cnpj,
        'email'     => $email,
        'endereco'  => $endereco,
        'bairro'    => $bairro,
        'cidade'    => $cidade,
        'estado'    => $estado,
        'cep'       => $cep,
        'senha'     => $senha
    ));
    
    echo "Dados inseridos com sucesso!";
} catch(PDOException $e) {
    echo "Erro ao inserir os dados: " . $e->getMessage();
}
?>