<?php

include('../database/mysql.php');


// Verifica se o ID foi fornecido via parâmetro GET
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    try {
        // Define o modo de erro do PDO como exceção
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Consulta para buscar os dados do registro com o ID fornecido
        $sql = "SELECT * FROM sites WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verifica se o registro foi encontrado
        if ($result) {
            json_encode($result);
        } else {
            echo json_encode(array('message' => 'Registro não encontrado.'));
        }
    } catch (PDOException $e) {
        echo json_encode(array('message' => 'Erro na conexão com o banco de dados: ' . $e->getMessage()));
    }
} else {
    echo json_encode(array('message' => 'ID não fornecido.'));
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Exemplo de leitura de JSON</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: <?php echo $result['primary_color']; ?>;
            color: <?php echo $result['text_color']; ?>;
        }

        h1 {
            color: <?php echo $result['primary_color']; ?>;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: <?php echo $result['secondary_color']; ?>;
            border-radius: 5px;
            margin-top: 50px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1><?php echo $result['title']; ?></h1>
        <img src="<?php echo $result['logo']; ?>" alt="Logo">
        <img width="400px" src="<?php echo $result['imagen']; ?>" alt="Imagen">
        <p><?php echo $result['text_sobre']; ?></p>
            <form method="POST" action="../../processAgenda.php">

            <input style="display: none;" type="text" value="<?php $id ?>">
        <h1>Agendamento</h1>
        <?php
        

                echo '<select name="unidades">';
                $sql = "SELECT * FROM unidades";
                $stmt = $pdo->query($sql);
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo '<option value="' . $row["id"] . '">' . $row["nome"] . '</option>';
                }
                echo '</select>';

                echo '<select name="servicos">';
                $stmt = $pdo->query('SELECT id, nome FROM servicos');
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo '<option value="' . $row["id"] . '">' . $row["nome"] . '</option>';
                }
                echo '</select>';


                echo '<select name="data">';
                $stmt = $pdo->query('SELECT id, data, hora FROM disponiveis');
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo '<option value="' . $row["id"] . '">' . $row["data"] . ' ' . $row["hora"] . '</option>';
                }
                echo '</select>';


                echo '<select name="funcionarios">';
                $stmt = $pdo->query('SELECT id, nome FROM funcionarios');
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo '<option value="' . $row["id"] . '">' . $row["nome"] . '</option>';
                }
                echo '</select>';

        ?>

        <input type="submit" value="Enviar">
    </form>
    </div>
</body>
</html>