<?php

// Função de logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.html');
    exit;
}

if(isset($_SESSION['user_id'])){
    $user_id = $_SESSION['user_id'];
} else {
    header('Location: login.html');
}