<?php

include('../database/mysql.php');

if (!isset($_GET['id'])) {
    echo 'ID do site não especificado.';
    exit();
}

$id = $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM sites WHERE id = :id");
$stmt->execute([
    'id' => $id
]);

if ($stmt->rowCount() === 0) {
    echo 'Site não encontrado.';
    exit();
}

$site = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nome = $_POST['nome'];
    $cpf = $_POST['cpf'];
    $email = $_POST['email'];
    $cargo = $_POST['cargo'];
    $idu = $_POST['unidade'];

    $stmt = $pdo->prepare("INSERT INTO funcionarios (nome, cpf, email, cargo, site_id, unidade_id) VALUES (:nome, :cpf, :email, :cargo, :site_id, :unidade_id)");

    try {
        $stmt->execute([
            'nome' => $nome,
            'cpf' => $cpf,
            'email' => $email,
            'cargo' => $cargo,
            'unidade_id' => $idu,
            'site_id' => $id
        ]);
        header('Location: ../../dashboard.php');
        exit();
    } catch (PDOException $e) {
        echo 'Erro ao criar o funcionário: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../../assets/css/form.css">
    <title>Criar Funcionário</title>
</head>
<body>
    <form action="" method="POST">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" required>

        <label for="cpf">CPF:</label>
        <input type="text" id="cpf" name="cpf" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="cargo">Cargo:</label>
        <input type="text" id="cargo" name="cargo" required>

        <label for="unidade">Unidade:</label>
        <select name="unidade">
            <?php

            $stmt = $pdo->prepare("SELECT id, nome FROM unidades WHERE site_id = :id");
            $stmt->bindParam(':id', $id);
            $stmt->execute();

                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $unidadeId = $row['id'];
                    $unidadeName = $row['nome'];
                    echo '<option value="' . $unidadeId . '">' . $unidadeName . '</option>';
                }
            ?>
        </select>

        <input type="submit" value="Criar Funcionário">    
        <a href="../../dashboard.php">Voltar</a>
    </form>
</body>
</html>