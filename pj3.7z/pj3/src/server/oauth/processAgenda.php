<?php
include('../database/mysql.php');

session_start();

if(isset($_GET['uid'])){
  
} else {
    header('Location: site.php');
}

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recebe os dados do formulário
    $unidade_id = $_POST['unidades'];
    $servico_id = $_POST['servicos'];
    $disponivel_id = $_POST['data'];
    $funcionario_id = $_POST['funcionarios'];
    $user_id = $_SESSION['user_id'];
    $site_id = $_POST['site_id'];


    // Busca as informações selecionadas nos campos do formulário
    $stmt = $pdo->prepare('SELECT nome FROM unidades WHERE id = :id');
    $stmt->bindParam(':id', $unidade_id);
    $stmt->execute();
    $unidade_nome = $stmt->fetchColumn();

    $stmt = $pdo->prepare('SELECT nome FROM servicos WHERE id = :id');
    $stmt->bindParam(':id', $servico_id);
    $stmt->execute();
    $servico_nome = $stmt->fetchColumn();

    $stmt = $pdo->prepare('SELECT data, hora FROM disponiveis WHERE id = :id');
    $stmt->bindParam(':id', $disponivel_id);
    $stmt->execute();
    $disponivel = $stmt->fetch(PDO::FETCH_ASSOC);
    $disponivel_data = $disponivel['data'];
    $disponivel_hora = $disponivel['hora'];

    $stmt = $pdo->prepare('SELECT nome FROM funcionarios WHERE id = :id');
    $stmt->bindParam(':id', $funcionario_id);
    $stmt->execute();
    $funcionario_nome = $stmt->fetchColumn();

    $status = "Pendente";

    // Cria a data e hora de agendamento
    date_default_timezone_set('America/Sao_Paulo');
    $agendamento_data = date('Y-m-d H:i:s');

    $stmt->bindParam(':user_id', $user_id);

    // Insere os dados no banco de dados
    $sql = "INSERT INTO agendamentos (unidade, servico, data, hora, funcionario, data_agendamento, user_id, status, site_id)
        VALUES (:unidade, :servico, :data, :hora, :funcionario, :data_agendamento, :uid, :status, :site_id)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':unidade', $unidade_nome);
    $stmt->bindParam(':servico', $servico_nome);
    $stmt->bindParam(':data', $disponivel_data);
    $stmt->bindParam(':hora', $disponivel_hora);
    $stmt->bindParam(':funcionario', $funcionario_nome);
    $stmt->bindParam(':data_agendamento', $agendamento_data);
    $stmt->bindParam(':uid', $user_id);
    $stmt->bindParam(':site_id', $site_id);
    $stmt->bindParam(':status', $status);
    $stmt->execute();

    // Retorna para a página anterior
    header('Location: agendamentos.php');
    exit();
}
?>