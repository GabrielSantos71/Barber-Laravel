<?php

include '../database/mysql.php';



if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $user_id = $_POST['user_id'];
    $title = $_POST['title'];
    $text_sobre = $_POST['text_sobre'];
    $logo = $_POST['logo'];
    $imagen = $_POST['imagen'];
    $primary_color = $_POST['primary_color'];
    $secondary_color = $_POST['secondary_color'];
    $text_color = $_POST['text_color'];

    if (isset($_POST['user_id'])) {

        $id = $_POST['user_id'];

        $stmt = $pdo->prepare("SELECT * FROM sites WHERE user_id = :id");
        $stmt->execute([
            'id' => $id
        ]);

        if ($stmt->rowCount() > 0) {
            echo "ID já existe na tabela.";
        }
    }

    $stmt = $pdo->prepare("INSERT INTO sites (user_id, title, text_sobre, logo, imagen, primary_color, secondary_color, text_color) 
                           VALUES (:user_id, :title, :text_sobre, :logo, :imagen, :primary_color, :secondary_color, :text_color)");
    $stmt->execute([
        'user_id' => $user_id,
        'title' => $title,
        'text_sobre' => $text_sobre,
        'logo' => $logo,
        'imagen' => $imagen,
        'primary_color' => $primary_color,
        'secondary_color' => $secondary_color,
        'text_color' => $text_color,
    ]);

    if ($stmt->rowCount() > 0) {
        echo "Dados do formulário foram salvos com sucesso!";
        exit();
    } else {
        echo "Ocorreu um erro ao salvar os dados do formulário.";
    }
}
?>