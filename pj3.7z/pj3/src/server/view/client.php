<?php

include('../database/mysql.php');


// Verifica se o ID foi fornecido via parâmetro GET
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    try {
        // Define o modo de erro do PDO como exceção
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Consulta para buscar os dados do registro com o ID fornecido
        $sql = "SELECT * FROM sites WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        

        // Verifica se o registro foi encontrado
        if ($result) {
            json_encode($result);
        } else {
            header('Location: error.php?id='.$id.'');
        }
    } catch (PDOException $e) {
        echo json_encode(array('message' => 'Erro na conexão com o banco de dados: ' . $e->getMessage()));
    }
} else {
    echo json_encode(array('message' => 'ID não fornecido.'));
}
?>