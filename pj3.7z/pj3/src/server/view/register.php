<?php

include('../database/mysql.php');
$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $site_id = $_GET['id'];



    $stmt = $pdo->prepare('SELECT * FROM clientes WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        echo "Este e-mail já está cadastrado. Por favor, tente outro e-mail.";
    } else {

        $stmt = $pdo->prepare('INSERT INTO clientes (email, senha, site_id) VALUES (?, ?, ?)');
        $stmt->execute([$email, $senha, $site_id]);

        echo "Registro realizado com sucesso!";

        header('Location: login.php?id='.$id.'');
        exit();
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Registro de Usuário</title>
</head>
<body>
    <h1>Registro de Usuário</h1>
    <form method="POST" action="">
        <label for="email">E-mail:</label>
        <input type="email" name="email" required>

        <label for="senha">Senha:</label>
        <input type="password" name="senha" required>

        <button type="submit">Registrar</button>
    </form>
</body>
</html>