
<?php

include('../database/mysql.php');


// Verifica se o ID foi fornecido via parâmetro GET
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    try {
        // Define o modo de erro do PDO como exceção
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Consulta para buscar os dados do registro com o ID fornecido
        $sql = "SELECT * FROM sites WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        

        // Verifica se o registro foi encontrado
        if ($result) {
            json_encode($result);
        } else {
            header('Location: error.php?id='.$id.'');
        }
    } catch (PDOException $e) {
        echo json_encode(array('message' => 'Erro na conexão com o banco de dados: ' . $e->getMessage()));
    }
} else {
    echo json_encode(array('message' => 'ID não fornecido.'));
}


    // Consulta para preencher o primeiro campo de seleção com unidades
    $unidadesQuery = "SELECT id, nome FROM unidades";
    $unidadesStmt = $pdo->prepare($unidadesQuery);
    $unidadesStmt->execute();
    $unidades = $unidadesStmt->fetchAll(PDO::FETCH_ASSOC);

    // Consulta para preencher o segundo campo de seleção com serviços
    $servicosQuery = "SELECT id, nome FROM servicos";
    $servicosStmt = $pdo->prepare($servicosQuery);
    $servicosStmt->execute();
    $servicos = $servicosStmt->fetchAll(PDO::FETCH_ASSOC);

    // Consulta para preencher o terceiro campo de seleção com datas
    $datasQuery = "SELECT id, data FROM disponiveis";
    $datasStmt = $pdo->prepare($datasQuery);
    $datasStmt->execute();
    $datas = $datasStmt->fetchAll(PDO::FETCH_ASSOC);

    // Consulta para preencher o quarto campo de seleção com funcionários
    $funcionariosQuery = "SELECT id, nome FROM funcionarios";
    $funcionariosStmt = $pdo->prepare($funcionariosQuery);
    $funcionariosStmt->execute();
    $funcionarios = $funcionariosStmt->fetchAll(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="area.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $result['title'];   ?></title>

    <style>
        body {
            background-color: <?php echo $result['primary_color'] ; ?> !important
        }
        * {
            color: <?php echo $result['text_color'] ; ?>
        }
        h1 {
            color: <?php echo $result['text_color'] ; ?> !important
        }
        form {
            color: <?php echo $result['text_color'] ; ?> !important
        }
        p {
            color: <?php echo $result['text_color'] ; ?> !important
        }
        a {
            text-decoration: none;
            border: <?php echo $result['secondary_color'] ; ?> 1px solid !important
        }
        .area-card {
            text-decoration: none;
            border: <?php echo $result['secondary_color'] ; ?> 1px solid !important
        }
        button {
            text-decoration: none;
            background: <?php echo $result['secondary_color'] ; ?> !important
        }
        </style>
</head>
<body>
<div class="area-container">
    <div class="area-nav">
        <img src="<?php echo $result['logo']; ?>" width="100px">
        <a href="login.php?id=<?php echo $id; ?>" class="btn">Area do Cliente</a>
    </div>
    <h1 class="area-title"><?php echo $result['title']; ?></h1>
    <div class="area-content">
        <div class="area-text-section">
            <h1 class="area-heading">
                <span><span class="seta"></span></span> Sobre
            </h1>
            <p class="area-text">
            <?php echo $result['text_sobre']; ?>
            </p>
            <img id="img" src="<?php echo $result['imagen']; ?>">
        </div>
        <form method="post" action="../processAgenda.php" class="area-agenda">
    <h1 class="area-heading"><span><span class="seta"></span></span> Agenda</h1>
    <select name="unidades" id="area-select" name="unidade">
        <option value="">Selecione uma unidade</option>
        <?php foreach ($unidades as $unidade): ?>
            <option value="<?php echo $unidade['id']; ?>"><?php echo $unidade['nome']; ?></option>
        <?php endforeach; ?>
    </select>
    <select name="servicos" id="area-select" name="servico">
        <option value="">Selecione um serviço</option>
        <?php foreach ($servicos as $servico): ?>
            <option value="<?php echo $servico['id']; ?>"><?php echo $servico['nome']; ?></option>
        <?php endforeach; ?>
    </select>
    <div class="area-button">
        <div class="area-flex">
            <p class="area-p">Data e Hora</p>
            <select id="area-select2" name="data">
                <option value="">Selecione uma data</option>
                <?php foreach ($datas as $data): ?>
                    <option value="<?php echo $data['id']; ?>"><?php echo $data['data']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="area-flex">
            <p class="area-p">Preferência de Funcionário</p>
            <select id="area-select2" name="funcionario">
                <option value="">Selecione um funcionário</option>
                <?php foreach ($funcionarios as $funcionario): ?>
                    <option value="<?php echo $funcionario['id']; ?>"><?php echo $funcionario['nome']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php 
            session_start();
            if(isset($_SESSION['user_id'])){
                $user_id = $_SESSION['user_id'];
                echo '<button class="area-button2"><span class="calendario"></span> Agendar</button>';
            } else {
                echo '<a href="login.php?id='.$id.'" class=""><span class="calendario"></span> Faça Login</a>';
            }
        ?>
    </div>
            <p class="area-p-armazzen">Porque agendar com a <?php echo $result['title']  ?> ?</p>
            <div class="area-armazzen">
                <div class="area-card">
                    <p class="area-p-armazzen2">Já agendamos:</p>
                    <?php
                        $sql = "SELECT COUNT(*) as total_linhas FROM agendamentos WHERE site_id = :id";
                        $stmt = $pdo->prepare($sql);
                        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

                        // Executa a query
                        $stmt->execute();

                        // Obtém o resultado
                        $row = $stmt->fetch(PDO::FETCH_ASSOC);
                        $total_linhas = $row["total_linhas"];

                        echo $total_linhas;
                    ?>
                </div>
                <div class="area-card">
                    <p class="area-p-armazzen2">Clientes Satisfeitos:</p>
                    <?php
                        $sql = "SELECT COUNT(*) as total_linhas FROM clientes WHERE site_id = :id";
                        $stmt = $pdo->prepare($sql);
                        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

                        // Executa a query
                        $stmt->execute();

                        // Obtém o resultado
                        $row = $stmt->fetch(PDO::FETCH_ASSOC);
                        $total_linhas = $row["total_linhas"];

                        echo $total_linhas;
                    ?>
                </div>
                <div class="area-card">
                    <p class="area-p-armazzen2">Estamos com:</p>
                    <?php
                        $sql = "SELECT COUNT(*) as total_linhas FROM unidades WHERE site_id = :id";
                        $stmt = $pdo->prepare($sql);
                        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

                        // Executa a query
                        $stmt->execute();

                        // Obtém o resultado
                        $row = $stmt->fetch(PDO::FETCH_ASSOC);
                        $total_linhas = $row["total_linhas"];

                        echo $total_linhas . " Unidades";
                    ?>
                </div>
            </div>
            </form>
    </div>
</div>
</body>
</html>
